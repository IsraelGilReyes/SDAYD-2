import{o}from"./bootstrap-CwzeWrlw.js";import{s as t,e as s}from"../jse/index-index-DKn2AIvu.js";const r=()=>{const e=t(!1);return s(()=>{e.value=o()}),e};export{r as u};
