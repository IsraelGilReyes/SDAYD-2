import{r as a,k as o}from"../jse/index-index-DKn2AIvu.js";const f=()=>{const e=a(new Map),s=r=>t=>{e.value.set(r,t)};return o(()=>{e.value=new Map}),[s,e]};export{f as u};
