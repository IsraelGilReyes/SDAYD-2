import{u as r,Q as u}from"./useBaseQuery-Dngy4zPV.js";function a(e,s){return r(u,e)}export{a as u};
