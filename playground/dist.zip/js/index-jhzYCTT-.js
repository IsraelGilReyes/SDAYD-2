import{C as s,A as t}from"./index-CPCNon4j.js";import{D as o}from"./bootstrap-CwzeWrlw.js";const l=o(s),m=o(t);export{l as C,m as R};
