import{w as o}from"./bootstrap-CwzeWrlw.js";const a=o("mdi:keyboard-esc"),i=o("mdi:wechat"),t=o("mdi:github"),d=o("mdi:google"),s=o("mdi:qqchat");export{t as M,d as a,s as b,i as c,a as d};
