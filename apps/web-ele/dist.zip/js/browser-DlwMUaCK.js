import{a as i}from"./bootstrap-CwKk_qi3.js";const t=()=>i&&/firefox/i.test(window.navigator.userAgent);export{t as i};
